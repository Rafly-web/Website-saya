export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  
  const { email, link, apply, token } = req.query;
  
  // Validasi Sederhana: Memastikan request datang dari UI setelah iklan (bisa dikembangkan)
  if (!email || !link) return res.status(400).json({ error: 'Missing parameters' });

  try {
    const response = await fetch(`https://alight-motion-ten.vercel.app/api/alight?action=verify&email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}&apply=${apply}`);
    const data = await response.json();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
}
