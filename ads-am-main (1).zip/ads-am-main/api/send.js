export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  
  const { email } = req.query;
  if (!email) return res.status(400).json({ error: 'Email required' });

  try {
    const response = await fetch(`https://alight-motion-ten.vercel.app/api/alight?action=send&email=${encodeURIComponent(email)}`);
    const data = await response.json();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
}
